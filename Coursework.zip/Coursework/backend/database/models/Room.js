const mongoose = require('mongoose')
const Schema = mongoose.Schema

const formDataSchema = new mongoose.Schema({
    firstName: {
      type: String,
      required: true
    },
    lastName: {
      type: String,
      required: true
    },
    phoneNumber: {
      type: String,
      required: true
    },
    dateRange: {
      start: {
        type: Date,
        required: true
      },
      end: {
        type: Date,
        required: true
      }
    }
  });

module.exports = mongoose.model('room', formDataSchema)