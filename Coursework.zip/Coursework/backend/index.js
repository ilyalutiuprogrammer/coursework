const express = require("express")
const bodyParser = require('body-parser')
const morgan = require('morgan')
const cors = require('cors')
const path = require('path')
const mongoDB = require('./database/index')
const {Router} = require('express');
const session = require('express-session')
const router = Router();

const config = require('./config/project')
const app = require("./utils/experssApp")

mongoDB;

const PORT = process.env.PORT || config.port;

app.listen(PORT, () => {
    console.log(`Server start at http://localhost:7770`)
})