const Review = require('../database/models/Review');

module.exports.review = async (req, res) => {
  try {
    const { name, review } = req.body;

    if (!name || !review) {
      return res.status(400).json(
        { 
          error: 'Обовьязково.' 
        });
    }

    const newReview = new Review({
      name,
      review,
    });

    await newReview.save();
    res.status(201).json({ message: 'Відгук добавлен.' });
  } 
  catch (ex) 
  {
    console.error(ex);
    res.status(500).json({ ex: 'Ошибка сервера.' });
  }
};
