const path = require('path')

module.exports.logout = (req, res) => 
{
    res.clearCookie("token")
    res.clearCookie("login")
    res.json("")
}