const Review = require('../database/models/Review');

module.exports.getReviews = async (req, res) => {
  try 
  {
    const reviews = await Review.find();
    res.json(reviews);
  } 
  catch (ex) 
  {
    console.error(ex);
    res.status(500).json({ ex: 'Ошибка сервера.' });
  }
};
