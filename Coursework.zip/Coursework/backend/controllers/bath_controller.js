const Bath = require('../database/models/Bath');

module.exports.rentBath = async (req, res) => {
  try {
    const existingBooking = await Bath.findOne({
      $and: [
        {
          startDate: { $eq: new Date(req.body.startDate) },
        },
        {
          $or: [
            {
              startTime: { $lte: req.body.endTime },
              endTime: { $gte: req.body.startTime },
            },
          ],
        },
      ],
    });

    if (existingBooking) {
      return res.status(400).json({ message: 'Выбранное время уже занято' });
    }

    const newBooking = new Bath({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      startTime: req.body.startTime,
      endTime: req.body.endTime,
      startDate: new Date(req.body.startDate),
    });

    await newBooking.save();

    res.status(201).json({ message: 'Баня успешно забронирована' });
  } catch (error) {
    console.error('Ошибка при бронировании бани:', error);
    res.status(500).json({ message: 'Внутренняя ошибка сервера' });
  }
};
