const User = require('../database/models/User');
const Room = require('../database/models/Room');
const Bath = require('../database/models/Bath');
const Fishing = require('../database/models/Fishing');

module.exports.getUserProfile = async (req, res) => {
  try {
    const userId = req.params.userId; 

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ error: 'Пользователь не найден' });
    }

    const rooms = await Room.find({ userId: user._id });
    const baths = await Bath.find({ userId: user._id });
    const fishings = await Fishing.find({ userId: user._id });

    const userProfileData = {
      user: {
        login: user.login,
      },
      rooms,
      baths,
      fishings,
    };

    res.json(userProfileData);
  } catch (ex) {
    console.error(ex);
    res.status(500).json({ error: 'Ошибка сервера.' });
  }
};
