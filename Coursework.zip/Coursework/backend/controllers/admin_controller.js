const Room = require('../database/models/Room');
const Bath = require('../database/models/Bath');
const Fishing = require('../database/models/Fishing');
const Review = require('../database/models/Review');
const User = require('../database/models/User');

module.exports.addRoom = async (req, res) => {
    try {
        const { firstName, lastName, phoneNumber, dateRange } = req.body;
    
        if (!firstName || !lastName || !phoneNumber || !dateRange) {
          return res.status(400).json({ error: 'Все поля формы обязательны для заполнения.' });
        }
    
        const startDate = new Date(dateRange[0]);
        const endDate = new Date(dateRange[1]);
    
        if (startDate >= endDate) {
          return res.status(400).json({ error: 'Дата начала должна быть раньше даты окончания.' });
        }
        const formData = await Room.create({
          firstName,
          lastName,
          phoneNumber,
          dateRange: {
            start: startDate,
            end: endDate,
          },
        });
    
        console.log('Данные формы успешно сохранены:', formData);
    
        res.status(201).json({ message: 'Данные формы успешно сохранены.', formData });
      } catch (error) {
        console.error(error);
    
        res.status(500).json({ error: 'Внутренняя ошибка сервера.' });
      }
};

module.exports.updateRoom = async (req, res) => {
  try {
    const { firstName, lastName, phoneNumber, dateRange } = req.body;
    const roomId = req.params.roomId;

    const updatedRoom = await Room.findByIdAndUpdate(
      roomId,
      {
        $set: { firstName, lastName, phoneNumber, dateRange },
      },
      { new: true }
    );

    if (!updatedRoom) {
      return res.status(404).json({ error: 'Комната не найдена' });
    }

    res.json(updatedRoom);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.deleteRoom = async (req, res) => {
  try {
    const roomId = req.params.roomId;

    const deletedRoom = await Room.findByIdAndRemove(roomId);

    if (!deletedRoom) {
      return res.status(404).json({ error: 'Комната не найдена' });
    }

    res.json(deletedRoom);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.getRooms = async (req, res) => {
    try {
      const rooms = await Room.find();
      res.json(rooms);
    } catch (error) {
      console.error('Error fetching rooms:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  };

  module.exports.addBath = async (req, res) => {
      try {
        const newBooking = new Bath({
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          startTime: req.body.startTime,
          endTime: req.body.endTime,
          startDate: new Date(req.body.startDate),
        });
    
        await newBooking.save();
    
        res.status(201).json({ message: 'Баня успешно забронирована' });
      } catch (error) {
        console.error('Ошибка при бронировании бани:', error);
        res.status(500).json({ message: 'Внутренняя ошибка сервера' });
      }
  };
  
  module.exports.getBaths = async (req, res) => {
    try {
      const baths = await Bath.find();
      res.json(baths);
    } catch (error) {
      console.error('Error fetching baths:', error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  };
  
  module.exports.updateBath = async (req, res) => {
    try {
      const { firstName, lastName, startTime, endTime, startDate } = req.body;
      const bathId = req.params.bathId;
  
      const updatedBath = await Bath.findByIdAndUpdate(
        bathId,
        {
          $set: { firstName, lastName, startTime, endTime, startDate },
        },
        { new: true }
      );
  
      if (!updatedBath) {
        return res.status(404).json({ error: 'Баня не найдена' });
      }
  
      res.json(updatedBath);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  };
  
  module.exports.deleteBath = async (req, res) => {
    try {
      const bathId = req.params.bathId;
  
      const deletedBath = await Bath.findByIdAndRemove(bathId);
  
      if (!deletedBath) {
        return res.status(404).json({ error: 'Баня не найдена' });
      }
  
      res.json(deletedBath);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Ошибка сервера' });
    }
  };



  module.exports.addFishing = async (req, res) => {
    try {
      const newBooking = new Fishing({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        startTime: req.body.startTime,
        endTime: req.body.endTime,
        startDate: new Date(req.body.startDate),
      });
  
      await newBooking.save();
  
      res.status(201).json({ message: 'Баня успешно забронирована' });
    } catch (error) {
      console.error('Ошибка при бронировании бани:', error);
      res.status(500).json({ message: 'Внутренняя ошибка сервера' });
    }
};

module.exports.getFishing = async (req, res) => {
  try {
    const fishing = await Fishing.find();
    res.json(fishing);
  } catch (error) {
    console.error('Error fetching fishing:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.updateFishing = async (req, res) => {
  try {
    const { firstName, lastName, startTime, endTime, startDate } = req.body;
    const fishingId = req.params.fishingId;

    const updatedFishing = await Fishing.findByIdAndUpdate(
      fishingId,
      {
        $set: { firstName, lastName, startTime, endTime, startDate },
      },
      { new: true }
    );

    if (!updatedFishing) {
      return res.status(404).json({ error: ' не найдена' });
    }

    res.json(updatedFishing);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.deleteFishing = async (req, res) => {
  try {
    const fishingId = req.params.fishingId;

    const deletedFishing = await Fishing.findByIdAndRemove(fishingId);

    if (!deletedFishing) {
      return res.status(404).json({ error: 'Баня не найдена' });
    }

    res.json(deletedFishing);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.deleteReview = async (req, res) => {
  try {
    const reviewId = req.params.reviewId;

    const deletedReview = await Review.findByIdAndRemove(reviewId);

    if (!deletedReview) {
      return res.status(404).json({ error: 'Отзыв не найден' });
    }

    res.json(deletedReview);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.getReview = async (req, res) => {
  try {
    const reviews = await Review.find();
    res.json(reviews);
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

module.exports.getUser = async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};