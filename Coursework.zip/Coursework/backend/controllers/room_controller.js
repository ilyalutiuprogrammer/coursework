const Room = require('../database/models/Room');

module.exports.roomAdd = async (req, res) => {
  try {
    const { firstName, lastName, phoneNumber, dateRange } = req.body;

    if (!firstName || !lastName || !phoneNumber || !dateRange) {
      return res.status(400).json({ error: 'Все поля формы обязательны для заполнения.' });
    }

    const startDate = new Date(dateRange[0]);
    const endDate = new Date(dateRange[1]);

    if (startDate >= endDate) {
      return res.status(400).json({ error: 'Дата начала должна быть раньше даты окончания.' });
    }
    const formData = await Room.create({
      firstName,
      lastName,
      phoneNumber,
      dateRange: {
        start: startDate,
        end: endDate,
      },
    });

    console.log('Данные формы успешно сохранены:', formData);

    res.status(201).json({ message: 'Данные формы успешно сохранены.', formData });
  } catch (error) {
    console.error(error);

    res.status(500).json({ error: 'Внутренняя ошибка сервера.' });
  }
};
