const bcryptjs = require('bcryptjs')
const jwt = require('jsonwebtoken')
const User = require('../database/models/User')
const config = require("../config/project")
const validation = require('../utils/Validation')
const express = require('express')

module.exports.login = async (req, res) =>
{
    if(validation.IsValidLogin(req.body.login) && validation.IsValidPassword(req.body.password)) 
    {
        const log = await User.findOne({login:req.body.login})
        if(log)
        {
            GetToken(req, log, res)
        }
        else
        {
            res.json("Error")
        }
    }
    else
    {
        res.json("Error")
    }
    
}

module.exports.register = async(req, res) =>
{
    const userLog = await User.findOne({login:req.body.login})
    if(userLog)
    {
        res.json(`Такий користувач існує`)
    }
    else
    {
        if(validation.IsValidLogin(req.body.login) && validation.IsValidPassword(req.body.password) && validation.IsValidEmail(req.body.email))
        {
                const Password = bcryptjs.hashSync(req.body.password);
                const user = new User(
                    {
                    login : req.body.login,
                    password : Password,
                    email : req.body.email
                })
                try
                {
                    await user.save();
                    const db = await User.findOne({login : req.body.login})
                    GetToken(req, db, res)
                }
                catch(ex)
                {
                    console.log(ex);
                }
        }
        else{
            res.json("Error")
        }
    }
}

function GetToken(req, login, res) 
{
    const check = bcryptjs.compareSync(req.body.password, login.password)
    if (check) 
    {
        const jwtToken = jwt.sign(
        {
            login: login.login,
            userId: login._id
        }, 
        config.secret, 
        { 
            expiresIn: 1000 * 60 * 60 * 24 
        })
        
        res.cookie('login', login.login)
        res.cookie('token', jwtToken)     
        res.status(200).json("")
    }
    else 
    {
        res.json("Error")
    }
}
