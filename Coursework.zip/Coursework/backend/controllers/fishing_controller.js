const Fishing = require('../database/models/Fishing');

module.exports.rentFishing = async (req, res) => {
  try {
    const existingBooking = await Fishing.findOne({
      $and: [
        {
          startDate: { $eq: new Date(req.body.startDate) },
        },
        {
          $or: [
            {
              startTime: { $lte: req.body.startTime },
              endTime: { $gt: req.body.startTime },
            },
            {
              startTime: { $lt: req.body.endTime },
              endTime: { $gte: req.body.endTime },
            },
            {
              startTime: { $gte: req.body.startTime },
              endTime: { $lte: req.body.endTime },
            },
          ],
        },
      ],
    });

    if (existingBooking) {
      return res.status(400).json({ message: 'Выбранное время уже занято' });
    }

    const newBooking = new Fishing({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      startTime: req.body.startTime,
      endTime: req.body.endTime,
      startDate: new Date(req.body.startDate),
    });

    await newBooking.save();

    res.status(201).json({ message: 'Місце успішно заброньовано' });
  } catch (error) {
    console.error('Ошибка:', error);
    res.status(500).json({ message: 'Ошибка 500' });
  }
};
