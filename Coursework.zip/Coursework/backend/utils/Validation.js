

const IsContainHtml = (str) => {
    const htmlPattern = /<[\s\S]*>/;
    return htmlPattern.test(str);
}

const IsValidLogin = (login) => {
    return login.length >= 3 && !IsContainHtml(login)
}
const IsValidPassword = (password) => {
    return password.length >= 3 && !IsContainHtml(password)
}
const IsValidEmail = (email) => {
    return email.length >= 5 && !IsContainHtml(email) && email.includes('@')
}
module.exports = {
    IsContainHtml,
    IsValidLogin,
    IsValidPassword,
    IsValidEmail
}