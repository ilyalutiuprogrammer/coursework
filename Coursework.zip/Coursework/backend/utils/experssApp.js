const config = require('../config/project')
const express = require("express")
const bodyParser = require('body-parser')
const morgan = require('morgan')
const cors = require('cors')
const path = require('path')
const authRouter = require('../routes/auth')
const userRouter = require('../routes/user')
const cookieParser = require("cookie-parser")
const reviewRouter = require('../routes/review')
const showReviewRouter = require('../routes/showReview')
const bathRouter = require('../routes/bath')
const roomRouter = require('../routes/room')
const fishingRouter = require('../routes/fishing')
const profileRouter = require('../routes/showProfile')
const adminRouter = require('../routes/admin')

const host = config.host;
const port = config.sessionPort;
const key = config.secret;

const app = express();

app.use(cookieParser(key))

const configCors = {
    credentials:true,
    origin:true
}

app.use(express.json());
app.use(morgan('dev'))
app.use(cors(configCors))
app.options('*', cors(configCors))
app.use(bodyParser.urlencoded({extended: true}))
app.use(bodyParser.json())

app.use('/api/auth/', authRouter);
app.use('/api/user/', userRouter);
app.use('/api/review/', reviewRouter);
app.use('/api/showReview/', showReviewRouter);
app.use('/api/bath/', bathRouter);
app.use('/api/room/', roomRouter);
app.use('/api/fishing/', fishingRouter);
app.use('/api/profile/', profileRouter);
app.use('/api/admin/', adminRouter);

module.exports = app;