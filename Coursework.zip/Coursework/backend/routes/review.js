const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const reviewController = require('../controllers/review_controller')
router.post('/add',  reviewController.review)

module.exports = router