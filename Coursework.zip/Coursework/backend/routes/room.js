const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const roomController = require('../controllers/room_controller')
router.post('/roomAdd',  roomController.roomAdd)

module.exports = router