const express = require("express")
const router = express.Router();
const userController = require('../controllers/user_controller')
const multer = require('multer')
const upload = multer()
const jwt = require('jsonwebtoken')
const config = require('../config/project')

router.get('/logout', authenticateToken, userController.logout)

function authenticateToken(req, res, save) 
{
    console.log(req.cookies)
    console.log(req.cookie)
    const token = req.cookies.token;
  
    if (!token) return res.json({ success: false, message: 'Незареєстрований' });
    jwt.verify(token, config.secret, (err, user) =>
     {
      if (err) return res.json({ success: false, message: 'Помилка' });
      req.user = user;
      save();
    });
  }

module.exports = router