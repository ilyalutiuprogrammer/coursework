const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const showReviewController = require('../controllers/showReview_controller')

router.get('/show', showReviewController.getReviews)

module.exports = router