const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const showProfile = require('../controllers/profile_controller')

router.get('/show', showProfile.getUserProfile)

module.exports = router