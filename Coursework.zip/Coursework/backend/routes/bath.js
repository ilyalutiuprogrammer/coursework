const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const bathController = require('../controllers/bath_controller')

router.post('/rent-bath',  bathController.rentBath)

module.exports = router