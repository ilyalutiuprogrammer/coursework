const express = require("express")
const router = express.Router();
const multer = require('multer')
const upload = multer()
const fishingController = require('../controllers/fishing_controller')

router.post('/rent-fishing',  fishingController.rentFishing)

module.exports = router