const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin_controller');

router.post('/addRoom', adminController.addRoom);
router.put('/updateRoom/:roomId', adminController.updateRoom);
router.delete('/deleteRoom/:roomId', adminController.deleteRoom);
router.get('/getRooms', adminController.getRooms);

router.post('/addBath', adminController.addBath);
router.get('/getBaths', adminController.getBaths);
router.put('/updateBath/:bathId', adminController.updateBath);
router.delete('/deleteBath/:bathId', adminController.deleteBath);

router.post('/addFishing', adminController.addFishing);
router.get('/getFishing', adminController.getFishing);
router.put('/updateFishing/:fishingId', adminController.updateFishing);
router.delete('/deleteFishing/:fishingId', adminController.deleteFishing);

router.delete('/deleteReview/:reviewId', adminController.deleteReview);
router.get('/getReview', adminController.getReview);

router.get('/getUser', adminController.getUser);

module.exports = router;