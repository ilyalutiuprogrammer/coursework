module.exports = {
    mongoUrl : "mongodb+srv://prigornevilla:IKssXN16mWoa24Dw@cluster0.4qpwc4p.mongodb.net/?retryWrites=true&w=majority"
}