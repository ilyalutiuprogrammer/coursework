module.exports = {
    secret : 'key777',
    host : '127.0.0.1',
    port : 7770,
    sessionPort : 6379
}