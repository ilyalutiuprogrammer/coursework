import './App.css';
import {Routes, Route, createBrowserRouter, createRoutesFromElements, RouterProvider} from 'react-router-dom'
import { MainPage } from './pages/MainPage/MainPage';
import { Register } from "./pages/Auth/Register/Register"
import { Login } from "./pages/Auth/Login/Login"
import { About } from "./pages/OtherPages/About"
import { ShowReviews } from "./pages/OtherPages/ShowReviews"
import { AddReviews } from "./pages/OtherPages/AddReviews"
import ReactDOM from 'react-dom';
import { Entertainment } from "./pages/OtherPages/Entertainment"
import { Room } from "./pages/OtherPages/Room"
import { MainWihthoutLogin } from './pages/MainWithoutLogin/MainWithoutLogin';
import { AboutWithoutLogin } from './pages/AboutWihtoutLogin/AboutWithoutLogin';
import { EntertainmentWithoutLogin } from './pages/EntertainmentWithoutLogin/EntertainmentWithoutLogin';
import { Bath } from './pages/OtherPages/Bath';
import { Fishing } from './pages/OtherPages/Fishing';
import { Admin } from './pages/Admin/Admin';
import { AdminBath } from './pages/Admin/AdminBath';
import { AdminFishing } from './pages/Admin/AdminFishing';
import { AdminReviews } from './pages/Admin/AdminReviews';
import { AdminUser } from './pages/Admin/AdminUser';

// import {NavLink} from 'react-router-dom'
// import {Container} from 'react-bootstrap';
// import {NavDropdown} from 'react-bootstrap';
import { Button, Navbar, NavbarBrand, NavbarCollapse, NavbarLink, NavbarToggle } from 'flowbite-react';

//import { Navbar, Nav } from 'react-bootstrap';


function App() {

  const router = createBrowserRouter(createRoutesFromElements(
    <Route path='/'>
      <Route index element={<MainWihthoutLogin />}></Route>
      <Route path='/main' element={<MainPage />}></Route>      
      <Route path='/register' element={<Register />}></Route>
      <Route path='/login' element={<Login />}></Route>
      <Route path='/about' element={<About />}></Route>
      <Route path='/showReviews' element={<ShowReviews />}></Route>
      <Route path='/addReviews' element={<AddReviews />}></Route>
      <Route path='/entertainment' element={<Entertainment />}></Route>
      <Route path='/room' element={<Room />}></Route>
      <Route path='/aboutWithout' element={<AboutWithoutLogin />}></Route>
      <Route path='/entertainmentWithout' element={<EntertainmentWithoutLogin />}></Route>
      <Route path='/Bath' element={<Bath />}></Route>
      <Route path='/Fishing' element={<Fishing />}></Route>
      <Route path='/admin' element={<Admin />}></Route>
      <Route path='/admin_Bath' element={<AdminBath />}></Route>
      <Route path='/admin_Fishing' element={<AdminFishing />}></Route>
      <Route path='/admin_Reviews' element={<AdminReviews />}></Route>
      <Route path='/admin_User' element={<AdminUser />}></Route>
    </Route>
  ))
  
  return (
    <div className="App">

      <RouterProvider router={router} />
      {/* <Routes>
        <Route path='/'>
          
        </Route>
      </Routes> */}
      
    </div>
  );
}

// const router = createBrowserRouter();

// ReactDOM.render(
//   <RouterProvider router={router}>
//     <App />
//   </RouterProvider>,
//   document.getElementById('root')
// );
export default App;
