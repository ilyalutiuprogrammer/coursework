import React from 'react';
import {
  MDBFooter,
  MDBContainer,
  MDBIcon,
  MDBInput,
  MDBCol,
  MDBRow,
  MDBBtn
} from 'mdb-react-ui-kit';

const Footer = () => {
  return (
    <MDBFooter data-bs-theme="dark" className='text-center text-white bg-body-tertiary'>
      <MDBContainer className='p-4'>
        <MDBRow>
          <MDBCol md='4'>
            <div className='mb-3'>
              <MDBIcon icon='phone' className='me-2' />
              <p href='tel:+1234567890' className='text-white'>+38(098)3564915</p>
            </div>
          </MDBCol>

          <MDBCol md='4'>
            <div className='mb-3'>
              <MDBIcon icon='envelope' className='me-2' />
              <p href='mailto:prigornevilla@gmail.com' className='text-white'>prigornevilla@gmail.com</p>
            </div>
          </MDBCol>

          <MDBCol md='4'>
            <div className='mb-3'>
              <MDBIcon icon='map-marker-alt' className='me-2' />
              <p className='text-white'>Полтавський район, с. Глибока балка, вул. Лялі-Убийвовк, 54</p>
            </div>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </MDBFooter>
  );
}

export { Footer };
