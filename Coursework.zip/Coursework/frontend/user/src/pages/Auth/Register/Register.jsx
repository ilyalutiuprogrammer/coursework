import React from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBCheckbox
}
from 'mdb-react-ui-kit';
import { MyNavBar } from '../../NavBarWithoutLogin/NavBarLogin';
import  Background  from '../../../img/back4.jpg';
import { Footer } from '../../Footer/Footer';
import axios from 'axios'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {Icon} from 'react-icons-kit';
import {eyeOff} from 'react-icons-kit/feather/eyeOff';
import {eye} from 'react-icons-kit/feather/eye'
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

const Register = () => {
  const [show, setShow] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleClose = () => {
    setShow(false);
    navigate('/main');
  };
  const handleShow = () => setShow(true);


  const navigate = useNavigate();
  const [password, setPassword] = useState('')
  const [login, setLogin] = useState('')
  const [email, setEmail] = useState('')
  const [type, setType] = useState('password');
  const [icon, setIcon] = useState(eyeOff);
  const handleToggle = () => {
    if (type==='password'){
       setIcon(eye);
       setType('text')
    } else {
       setIcon(eyeOff)
       setType('password')
    }
 }
 const ClearInput = () => {
  setPassword("")
  setLogin("")
  setEmail("")
 }

  const RegisterSubmit = (e) => {
      e.preventDefault();
      axios.post(`http://localhost:7770/api/auth/register`, {
          login : login,
          password : password,
          email : email
      })
          .then(v => {
              console.log(v)
              if(v.data === ""){
                setIsAuthenticated(true);
                handleShow();
              }
              else {
                  ClearInput();
                  
              }
          })
              
  }


  return (
    <div  style={{ backgroundImage: `url(${Background})`, height:'110vh'  }}>
    <MyNavBar />
    <br/><br/><br/><br/><br/>
    <MDBContainer fluid className='d-flex align-items-center justify-content-center'>
      <div className='mask gradient-custom-3'></div>
      <MDBCard className='bg-dark' style={{borderRadius: '1rem',maxWidth: '600px',  marginTop: '100px'}}>
        <MDBCardBody className='px-5'>
          <form onSubmit={(e) => RegisterSubmit(e)}>
          <h2 className="fw-bold text-uppercase text-white text-center mb-5 mt-3">Реєстрація</h2>
          <MDBInput wrapperClass='mb-4' labelClass='text-white' onChange={(e) => setLogin(e.target.value)} value={login} name="login" id="login" placeholder='Логін' size='lg' type='text' required minLength={3}/>
          <MDBInput wrapperClass='mb-4' labelClass='text-white' placeholder='Пошта' onChange={(e) => setEmail(e.target.value)}  name="email" value={email} pattern="/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i" size='lg' id="email" required type='email'/>
          <div className='mb-4' style={{ display: 'flex', alignItems: 'center' }}>
          <MDBInput  
            size="lg"
            type={type}
            name="password"
            placeholder="Пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password" 
            required 
            minLength={3}
          />
          <span onClick={handleToggle} style={{ color: 'white' }}>
            <Icon icon={icon} size={40}/>
          </span>
        </div>

          <div className='d-flex flex-row justify-content-center mb-4'>
            <MDBCheckbox name='flexCheck' id='flexCheckDefault' labelClass='text-white' label='Я погоджуюсь з правилами сайту' />
          </div>
          <div>
            <input name="Reg" id="Reg" type="submit" style={{ fontSize: '20px' }} className='mb-4 w-100 gradient-custom-4 btn btn-primary'  value="Створити"/>
          </div>
          <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Оповіщення</Modal.Title>
        </Modal.Header>
        <Modal.Body>Ви успішно зареєструвалися!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Закрити
          </Button>
        </Modal.Footer>
      </Modal>
          </form>
        </MDBCardBody>
      </MDBCard>
    </MDBContainer>

    <br/>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <Footer/>
    </div>
  );
}

export {Register};