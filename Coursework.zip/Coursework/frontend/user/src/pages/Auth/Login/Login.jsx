import React from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBIcon
}
from 'mdb-react-ui-kit';
import  Background  from '../../../img/back4.jpg';
import { MyNavBar } from '../../NavBarWithoutLogin/NavBarLogin';
import 'bootstrap/dist/css/bootstrap.min.css';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import {NavLink, useNavigate} from 'react-router-dom'
import { Footer } from '../../Footer/Footer';
import {useState, useEffect} from 'react'
import axios from 'axios'
import {Icon} from 'react-icons-kit';
import {eyeOff} from 'react-icons-kit/feather/eyeOff';
import {eye} from 'react-icons-kit/feather/eye'
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

const Login = () => {
  const [show, setShow] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleClose = () => {
    setShow(false);
    navigate('/main');
  };
  const handleShow = () => setShow(true);

  const navigate = useNavigate()
 
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [type, setType] = useState('password');
  const [icon, setIcon] = useState(eyeOff);
  
  const ClearInput = () => {
      setLogin("");
      setPassword("")
  }
  const handleToggle = () => {
    if (type==='password'){
       setIcon(eye);
       setType('text')
    } else {
       setIcon(eyeOff)
       setType('password')
    }
 }
  const Sign = (e) => {
      e.preventDefault();

      axios.post('http://localhost:7770/api/auth/login', {
          login : login,
          password : password
      })
      .then(v => {
          console.log(v)
          if(v.data === "") {
            setIsAuthenticated(true);
            handleShow();
          }
          else {
              ClearInput();
          }
      })
      
  }
  useEffect(() => {
    if (isAuthenticated) {
      setTimeout(() => {
        navigate('/main');
      }, 2000); 
    }
  }, [isAuthenticated, navigate]);
  return (
    <div  style={{ backgroundImage: `url(${Background})`, height:'110vh'  }}>
    <MyNavBar />
    <br/><br/><br/><br/>
    <form onSubmit={e => Sign(e)}>
    <MDBContainer fluid>

      <MDBRow className='d-flex justify-content-center align-items-center h-100'>
        <MDBCol col='12'>

          <MDBCard className='bg-dark text-white mx-auto' style={{borderRadius: '1rem', maxWidth: '400px', marginTop: '100px'}}>
            <MDBCardBody className='p-5 d-flex flex-column align-items-center mx-auto w-100'>

              <h2 className="fw-bold mb-2 text-uppercase">Вхід</h2>
              <p className="text-white-50 mb-5">Будь ласка введіть свій логін та пароль!</p>

              <MDBInput wrapperClass='mb-4 mx-5 w-100' labelClass='text-white' onChange={(e) => setLogin(e.target.value)} value={login} name="login" id="login"  placeholder="Логін" type='login' size="lg" required/>
              <div className='mx-5 mb-4 w-100' style={{ display: 'flex', alignItems: 'center' }}>
              <MDBInput 
                size="lg"
                labelClass='text-white'
                type={type}
                //wrapperClass='mb-4 mx-5 w-100'
                name="password"
                placeholder="Пароль"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password" 
                required
              />
              <span className="flex justify-around items-center" onClick={handleToggle}>
                <Icon className="absolute mr-10" icon={icon} size={40}/>
              </span>
            </div>

              <button type="submit" name="Sign" id="Sign" style={{ fontSize: '20px' }} className='mb-5 w-100 gradient-custom-4 btn btn-primary' size='lg'>Увійти</button>
              <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Оповіщення</Modal.Title>
        </Modal.Header>
        <Modal.Body>Ви увійшли до свого облікового запису!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Закрити
          </Button>
        </Modal.Footer>
      </Modal>
              <div>
                <p className="mb-0">
                    У вас ще нама облікового запису? 
                <Nav.Link as={NavLink} to="/register" className="text-white-50 fw-bold" style={{ textDecoration: 'underline', color: 'gray' }}>
                    Реєстрація
                </Nav.Link>
                </p>
              </div>
            </MDBCardBody>
          </MDBCard>

        </MDBCol>
      </MDBRow>

    </MDBContainer>
    </form>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <Footer/>

    </div>
  );
}

export { Login };