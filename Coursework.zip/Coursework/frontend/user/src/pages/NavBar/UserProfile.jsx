// import { MDBCard, MDBCardImage, MDBCardText, MDBTypography } from 'mdb-react-ui-kit';
// import React, { useState, useEffect } from 'react';

// const UserProfile = ({ onClose }) => {
//   const [visible, setVisible] = useState(true);

//   return (
//     <MDBCard style={{ 

//          borderRadius: '20px', padding: '20px', marginTop:'520px', 
//          marginRight:"10px", 
//         // transition: 'background-color 0.3s, opacity 0.3s, transform 0.3s',
//         // boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
//         // backdropFilter: 'blur(10px)',
//         // WebkitBackdropFilter: 'blur(10px)',
//         // backgroundColor: 'rgba(255, 255, 255, 0.2)',
//       }}
      
//     >
//       <MDBCardImage
//         style={{ width: '100px', height: '100px', objectFit: 'cover', borderRadius: '50%', border: '3px solid #fff' }}
//         className="img-fluid"
//         src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-2.webp'
//         alt='User Avatar'
//       />

//       <MDBCardText className="mt-3">
//         <MDBTypography tag='h3'>Имя пользователя</MDBTypography>
//         <div className="d-flex align-items-center mb-0">
//           <p className="mb-0 me-2">@sheisme</p>
//         </div>
//       </MDBCardText>
//       <hr />

//       <div className="mb-3">
//         <MDBTypography tag='h6'>Дополнительная информация</MDBTypography>
//         <div className="d-flex flex-column">
//           <div className="mb-2">
//             <strong>Аренда комнаты:</strong> Доступно
//           </div>
//           <div className="mb-2">
//             <strong>Аренда бани:</strong> Недоступно
//           </div>
//           <div>
//             <strong>Аренда рыбалки:</strong> Доступно
//           </div>
//         </div>
//       </div>

//       <button className='btn btn-primary' onClick={onClose}>
//         Закрыть
//       </button>
//     </MDBCard>
//   );
// };

// export default UserProfile;
