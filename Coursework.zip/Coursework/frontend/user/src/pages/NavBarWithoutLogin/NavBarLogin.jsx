import {MyNavBarCss} from './NavBarLogin.css'
import { NavLink } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';

const MyNavBar = () => {
  const [prevScrollPos, setPrevScrollPos] = useState(0);
  const [visible, setVisible] = useState(true);

  const handleScroll = () => {
    const currentScrollPos = window.pageYOffset;
    const isScrolledUp = prevScrollPos > currentScrollPos;

    setVisible((isScrolledUp && currentScrollPos > 0) || currentScrollPos < 10);

    setPrevScrollPos(currentScrollPos);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [prevScrollPos, visible]);

  return (
    <Navbar
      className={`fixed-top ${visible ? 'nav-show' : 'nav-hide'}`}
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        height: '70px',
        transition: 'background-color 0.3s, opacity 0.3s, transform 0.3s',
        boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)', 
      }}
      collapseOnSelect
      expand="lg"
    >
      <Container>
        <Navbar.Brand as={NavLink} to="/">
          База-відпочинку
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={NavLink} to="/aboutWithout">
              Про нас
            </Nav.Link>
            <Nav.Link as={NavLink} to="/entertainmentWithout">
              Галерея
            </Nav.Link>
          </Nav>
          <Nav>
            <Nav.Link as={NavLink} to="/login">
              Увійти
            </Nav.Link>
            <Nav.Link as={NavLink} to="/register" eventKey={2}>
              Зареєструватися
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export { MyNavBar };
