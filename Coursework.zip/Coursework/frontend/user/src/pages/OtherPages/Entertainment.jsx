import React, { useState } from 'react';
import { MyNavBar } from '../NavBar/MyNavBar';
import { Footer } from '../Footer/Footer';
import Gallery from 'react-image-gallery';
import 'react-image-gallery/styles/css/image-gallery.css';
import Background from '../../img/title6.jpeg';
import Background2 from '../../img/title1.jpg';
import Background3 from '../../img/title2.jpg';
import Background4 from '../../img/title3.jpg';
import Background5 from '../../img/title4.jpg';
import Background6 from '../../img/title5.jpg';
import Background7 from '../../img/title7.png';
import Background8 from '../../img/title8.png';
import Background9 from '../../img/Screenshot_1.png';
import Background10 from '../../img/title9.png';
import Background11 from '../../img/title10.png';
import Background12 from '../../img/title12.png';
import Background13 from '../../img/title13.png';
import Background14 from '../../img/title14.png';
import Background15 from '../../img/title15.png';
import Background16 from '../../img/titl16.png';
import Background20 from '../../img/title20.png';
import Background21 from '../../img/title21.png';
import {EntertainmentCSS} from './Entertainment.css'
import BackSite from '../../img/back2.jpg';
import {
  MDBContainer,
  MDBCol,
  MDBLightbox,
  MDBRow,
} 
from 'mdb-react-ui-kit';
const Entertainment = () => 
{
  return (
    <div 
    style={{
        background: `url(${BackSite}) center center/cover no-repeat fixed`,
        minHeight: '100vh',
        overflow: 'hidden',
      }}
      >
      <MyNavBar />
      <br/><br/><br/>
      <MDBRow style={{ padding: '5px' }}>
      <MDBCol lg={4} md={12} className='mb-4 mb-lg-0'>
        <img
          src={Background}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Boat on Calm Water'
        />

        <img
           src={Background2}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
         <img
           src={Background9}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
        <img
           src={Background10}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
         <img
           src={Background15}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
         <img
           src={Background16}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
      </MDBCol>

      <MDBCol lg={4} className='mb-4 mb-lg-0'>
        <img
           src={Background3}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Mountains in the Clouds'
        />

        <img
           src={Background6}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Boat on Calm Water'
        />
        <img
          src={Background8}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
        <img
           src={Background11}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
        <img
           src={Background14}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
        <img
           src={Background21}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Wintry Mountain Landscape'
        />
      </MDBCol>

      <MDBCol lg={4} className='mb-4 mb-lg-0'>
        <img
           src={Background4}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Waves at Sea'
        />

        <img
           src={Background5}
           className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
        <img
          src={Background7}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
         <img
          src={Background12}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
        <img
          src={Background13}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
        <img
          src={Background20}
          className='w-100 shadow-1-strong rounded mb-4'
          alt='Yosemite National Park'
        />
      </MDBCol>
    </MDBRow>
      {/* <Footer /> */}
    </div>
  );
};

export { Entertainment };
