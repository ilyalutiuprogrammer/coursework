import { NavLink } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useRef, useState } from 'react';
import { MyNavBar } from '../NavBar/MyNavBar';
import { Footer } from '../Footer/Footer';
import Background from '../../img/blur12.png';
import Background2 from '../../img/title_1.png';
import Background3 from '../../img/title_2.png';
import Background4 from '../../img/title_3.png';

import BackSite from '../../img/back2.jpg';
import { motion } from 'framer-motion';

const About = () => {
    const fadeInLeft = {
        hidden: { opacity: 0, x: -50 },
        visible: { opacity: 1, x: 0 },
      };
    
      const fadeInRight = {
        hidden: { opacity: 0, x: 50 },
        visible: { opacity: 1, x: 0 },
      };
    
      const [isVisibleSection1, setIsVisibleSection1] = useState(false);
      const [isVisibleSection2, setIsVisibleSection2] = useState(false);
      const [isVisibleSection3, setIsVisibleSection3] = useState(false);
      const [isVisibleSection4, setIsVisibleSection4] = useState(false);
      const [isVisibleSection5, setIsVisibleSection5] = useState(false);
      const [isVisibleSection6, setIsVisibleSection6] = useState(false);
      const [isVisibleSection7, setIsVisibleSection7] = useState(false);
      const [isVisibleSection8, setIsVisibleSection8] = useState(false);
      const [isVisibleSection9, setIsVisibleSection9] = useState(false);

    
      const section1Ref = useRef(null);
      const section2Ref = useRef(null);
      const section3Ref = useRef(null);
      const section4Ref = useRef(null);
      const section5Ref = useRef(null);
      const section6Ref = useRef(null);
      const section7Ref = useRef(null);
      const section8Ref = useRef(null);
      const section9Ref = useRef(null);

      const handleScroll = () => {
        const section1Top = section1Ref.current?.getBoundingClientRect()?.top || 0;
        const section2Top = section2Ref.current?.getBoundingClientRect()?.top || 0;
        const section3Top = section3Ref.current?.getBoundingClientRect()?.top || 0;
        const section4Top = section4Ref.current?.getBoundingClientRect()?.top || 0;
        const section5Top = section5Ref.current?.getBoundingClientRect()?.top || 0;
        const section6Top = section6Ref.current?.getBoundingClientRect()?.top || 0;
        const section7Top = section7Ref.current?.getBoundingClientRect()?.top || 0;
        const section8Top = section8Ref.current?.getBoundingClientRect()?.top || 0;
        const section9Top = section9Ref.current?.getBoundingClientRect()?.top || 0;

        setIsVisibleSection1(section1Top < window.innerHeight);
        setIsVisibleSection2(section2Top < window.innerHeight);
        setIsVisibleSection3(section3Top < window.innerHeight);
        setIsVisibleSection4(section4Top < window.innerHeight);
        setIsVisibleSection5(section5Top < window.innerHeight);
        setIsVisibleSection6(section6Top < window.innerHeight);
        setIsVisibleSection7(section7Top < window.innerHeight);
        setIsVisibleSection8(section8Top < window.innerHeight);
        setIsVisibleSection9(section9Top < window.innerHeight);

      };
    
      useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        handleScroll();
        return () => {
          window.removeEventListener('scroll', handleScroll);
        };
      }, []);
    
  return (
    <div style={{
        background: `url(${BackSite}) center center/cover no-repeat fixed`,
        minHeight: '100vh',
        overflow: 'hidden',
      }}>
      <MyNavBar />
      <br/><br/><br/>
      <div style={{ display: 'flex', padding: '50px' }}>
        {/* <div style={{ flex: 1 }}>
          <img src={Background} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div> */}
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <h2>Майбутнє</h2>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section2Ref}
              initial="hidden"
              animate={isVisibleSection2 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            Наша історія лише починається. Ми впевнені, що майбутнє приховує безмежні можливості для нових інновацій, надзвичайних вражень та подальшого розвитку нашого бренду.
            Ми вважаємо, що наш бренд — це не просто товар чи послуга. Це спільнота людей, які об'єднані спільною ціллю створення чогось великого та значущого.

            </motion.p>
            
          </div>
        </div>
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #007BFF', width: '50%', margin: 'auto' }} />
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2>Наш Бренд</h2>
            <br/>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section3Ref}
              initial="hidden"
              animate={isVisibleSection3 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            Ласкаво просимо в світ нашого бренду, де кожен елемент нашої історії — це крок до створення унікального та значущого досвіду для наших клієнтів. 
            </motion.p>
            <br/>
            <br/>     
            <motion.p
              ref={section3Ref}
              initial="hidden"
              animate={isVisibleSection3 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            Дозвольте нам розповісти вам про те, як народжується та розвивається бренд, який вас оточує.                     </motion.p>
          </div>
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Background2} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #FF6347', width: '50%', margin: 'auto' }} />
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <img src={Background3} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <h2>Наші Досягнення: Визнання у Світі Інновацій та Якості</h2>
            <br/>
            <br/>  
            <br/>
            <br/>  
            <motion.p
              ref={section4Ref}
              initial="hidden"
              animate={isVisibleSection4 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            У світі, де конкуренція висока, ми пишаємося тим, що наші зусилля визнаються та винагороджуються. Наш бренд стежить за вдосконаленням і прагне до досягнень у всіх аспектах нашої діяльності.
          </motion.p>
          <br/>
          <br/> 
          <motion.p
              ref={section4Ref}
              initial="hidden"
              animate={isVisibleSection4 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
           Ось деякі з наших ключових досягнень та нагород:
          </motion.p>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2 style={{ textAlign:'left', marginLeft:"70px" }}>1. Інноваційні Рішення:</h2>
            <motion.p
              ref={section5Ref}
              initial="hidden"
              animate={isVisibleSection5 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            Ми завжди прагнемо бути на передовій технологій та творчих рішень. Наші інноваційні продукти визнані за їхню передовість та внесок у сучасні стандарти.            </motion.p>
          </div>
        </div>
        {/* <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Background} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div> */}
      </div>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2 style={{ textAlign:'left', marginLeft:"70px" }}>2. Нагороди за Дизайн:</h2>
            <motion.p
              ref={section5Ref}
              initial="hidden"
              animate={isVisibleSection5 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px', marginLeft:"60px" }}
            >
            Естетика є не менш важливою, ніж функціональність. Наші продукти були відзначені нагородами за винятковий дизайн, що відображає нашу пристрасну відданість естетиці. </motion.p>
          </div>
        </div>
        {/* <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Background} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div> */}
      </div>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2 style={{ textAlign:'left', marginLeft:"70px" }}>3. Високі Стандарти Якості:</h2>
            <motion.p
              ref={section5Ref}
              initial="hidden"
              animate={isVisibleSection5 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px' }}
            >
            Нагороди за відповідність високим стандартам якості є визнанням нашої постійної уваги до деталей та зобов'язанням до задоволення вимог наших клієнтів.

</motion.p>
          </div>
        </div>
        {/* <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Background} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div> */}
      </div>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2 style={{ textAlign:'left', marginLeft:"70px" }}>4. Вдячність наших Клієнтів:</h2>
            <motion.p
              ref={section5Ref}
              initial="hidden"
              animate={isVisibleSection5 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px',marginRight:"200px" }}
            >
            Найбільша нагорода для нас - це визнання наших клієнтів. Завдяки їхньому довір'ю та підтримці, ми продовжуємо рости та розвиватися.
          </motion.p>
          </div>
        </div>
        {/* <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Background} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div> */}
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #FF6347', width: '50%', margin: 'auto' }} />
      <div style={{ display: 'flex', padding: '50px' }}>
        
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <h2>Здоров'я та Екологічні Ініціативи</h2>
            <br/>
          <br/> 
          <br/>
          <br/> 
            <motion.p
              ref={section6Ref}
              initial="hidden"
              animate={isVisibleSection6 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px'}}
            >
Ми віримо, що наше здоров'я і добробут нерозривно пов'язані з здоров'ям нашої планети.           </motion.p>
<br/>
          <br/> 
            <motion.p
              ref={section6Ref}
              initial="hidden"
              animate={isVisibleSection6 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'23px'}}
            >
Тому ми приділяємо особливу увагу екологічним ініціативам, які спрямовані на створення стійкого та здорового середовища.              </motion.p>
          </div>
          
        </div><div style={{ flex: 1 }}>
          <img src={Background4} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
      </div>      
      <Footer />
    </div>
  );
};

export { About };
