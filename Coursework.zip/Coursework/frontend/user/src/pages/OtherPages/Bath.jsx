import React, { useState } from 'react';
import { MyNavBar } from '../NavBar/MyNavBar';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import { Row, Col, Image, Form } from 'react-bootstrap';
import Background from '../../img/back2.jpg';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import Title5 from '../../img/title5.jpg';
import Modal from 'react-bootstrap/Modal';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput
} from 'mdb-react-ui-kit';
import { registerLocale, setDefaultLocale } from "react-datepicker";
import uk from "date-fns/locale/uk";
registerLocale("uk", uk);

const Bath = () => {
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const ClearInput = () => {
    setFirstName("");
    setLastName("");
    setStartTime('');
    setEndTime('');
    setStartDate(new Date());
  };

  const handleStartTimeChange = (time) => {
    setStartTime(time);
  };

  const handleEndTimeChange = (time) => {
    setEndTime(time);
  };

  const handleButtonClick = (e) => {
    e.preventDefault();

    if (firstName && lastName && startTime && endTime && startDate) {
      axios.post('http://localhost:7770/api/bath/rent-bath', {
        firstName: firstName,
        lastName: lastName,
        startTime: startTime,
        endTime: endTime,
        startDate: startDate,
      })
        .then(response => {
          console.log(response);
          if (response.data === '') {
            navigate('/showReviews');
          } else {
            ClearInput();
          }
        })
        .catch(error => {
          console.error(error);
          if (error.response && error.response.status === 400) {
            // Ошибка занятости времени на одинаковую дату
            setShowModal(true);
            setModalMessage(error.response.data.message);
          }
        });
    } else {
      setShowModal(true);
      setModalMessage('Будь ласка, заповність усі поля.');
    }
  };



  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>
      <MyNavBar />

      <div style={{ backgroundImage: `url(${Background})`, height: '100vh' }}>
        <br /><br /><br />
        <form onSubmit={(e) => e.preventDefault()}>
          <MDBContainer fluid>
            <MDBRow>

              <MDBCol sm='6'>

                <div className='d-flex flex-row ps-5 pt-5'>
                  <span className="h1 fw-bold mb-0">Оренда лазні</span>
                </div>

                <div className='d-flex flex-column justify-content-center h-custom-2 w-75 pt-4'>
                  <MDBInput
                    onChange={(e) => setFirstName(e.target.value)}
                    value={firstName}
                    wrapperClass='mb-4 mx-5 w-100'
                    placeholder='Ваше ім`я'
                    size="lg"
                  />
                  <MDBInput
                    onChange={(e) => setLastName(e.target.value)}
                    value={lastName}
                    wrapperClass='mb-4 mx-5 w-100'
                    placeholder='Ваше прізвище'
                    size="lg"
                  />
                  <DatePicker
                    selected={startTime}
                    onChange={handleStartTimeChange}
                    placeholderText='Початок оренди'
                    showTimeSelect
                    showTimeSelectOnly
                    timeIntervals={15}
                    timeCaption="Time"
                    dateFormat="h:mm aa"
                    className='form-control mb-4 mx-5 w-100 fs-5'
                  />
                  <DatePicker
                    selected={endTime}
                    onChange={handleEndTimeChange}
                    placeholderText='Кінець оренди'
                    className='form-control mb-4 mx-5 w-100 fs-5'
                    showTimeSelect
                    showTimeSelectOnly
                    timeIntervals={15}
                    timeCaption="Time"
                    dateFormat="h:mm aa"
                  />
                  <Calendar
                    onChange={(date) => setStartDate(date)}
                    value={startDate}
                    locale="uk"
                    className='form-control mb-4 mx-5 w-100 fs-5'
                  />

                  <button
                    style={{ fontSize: '22px' }}
                    onClick={handleButtonClick}
                    className="mb-4 px-5 mx-5 w-100 btn btn-primary"
                  >
                    Оренда
                  </button>
                </div>

              </MDBCol>

              <MDBCol sm='6' className='d-none d-sm-block px-0'>
                <img
                  src={Title5}
                  className='w-100'
                  style={{ height: '847px', objectFit: 'cover', objectPosition: 'left' }}
                  alt="Description of the image"
                />
              </MDBCol>

            </MDBRow>

          </MDBContainer>
        </form>

        <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Помилка</Modal.Title>
        </Modal.Header>
        <Modal.Body>{modalMessage}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Закрити
          </Button>
        </Modal.Footer>
      </Modal>
      </div>
    </div>
  );
};

export { Bath };
