import React, { useState } from 'react';
import axios from 'axios';
import { MyNavBar } from '../NavBar/MyNavBar';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import { Row, Col, Image, Form } from 'react-bootstrap';
import Background from '../../img/blur12.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import Modal from 'react-bootstrap/Modal';
import Title4 from '../../img/title4blur.png';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
} from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom';
import { registerLocale, setDefaultLocale } from 'react-datepicker';
import uk from 'date-fns/locale/uk';
import 'react-datepicker/dist/react-datepicker.css';

registerLocale('uk', uk);
setDefaultLocale('uk');

const Room = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phoneNumber: '+380',
    dateRange: [new Date(), new Date()],
  });
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [showEmptyFieldsModal, setShowEmptyFieldsModal] = useState(false);

  const ClearInput = () => {
    setFormData({
      firstName: '',
      lastName: '',
      phoneNumber: '+380',
      dateRange: [new Date(), new Date()],
    });
  };

  const handleButtonClick = async (e) => {
    e.preventDefault();

    if (
      formData.firstName &&
      formData.lastName &&
      formData.phoneNumber &&
      formData.dateRange[0] &&
      formData.dateRange[1]
    ) {
      try {
        const response = await axios.post(
          'http://localhost:7770/api/room/roomAdd',
          formData
        );
        console.log(response);
        if (response.data === '') {
          navigate('/showReviews');
        } else {
          ClearInput();
        }
      } catch (error) {
        console.error(error);
        if (error.response && error.response.status === 400) {
          setShowModal(true);
          setModalMessage(error.response.data.error);
        }
      }
    } else {
      setShowEmptyFieldsModal(true);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };
  const handleCloseEmptyFieldsModal = () => {
    setShowEmptyFieldsModal(false);
  };

  const handlePhoneNumberChange = (e) => {
    const value = e.target.value.replace(/\D/g, '');

    if (value.length <= 12) {
      if (!value) {
        setFormData({
          ...formData,
          phoneNumber: '+380' + value,
        });
      } else {
        setFormData({
          ...formData,
          phoneNumber: value,
        });
      }
    }
  };

  const handleCalendarChange = (value) => {
    setFormData({
      ...formData,
      dateRange: value,
    });
  };

  return (
    <div
      style={{
        background: `url(${Title4}) center center/cover no-repeat fixed`,
        minHeight: '100vh',
        overflow: 'hidden',
      }}
    >
      <MyNavBar />
      <br />
      <br />
      <form onSubmit={(e) => e.preventDefault()}>
        <MDBContainer
          fluid
          className='w-100 p-3 background-radial-gradient overflow-hidden'
        >
          <MDBRow>
            <MDBCol
              md='6'
              className='text-center text-md-start d-flex flex-column justify-content-center'
            >
              <h1
                className='my-5 display-3 fw-bold ls-tight px-3'
                style={{ color: 'hsl(218, 81%, 95%)' }}
              >
                Оренда <br />
                <span style={{ color: 'hsl(218, 81%, 75%)' }}>
                  невеличкого будинку
                </span>
              </h1>

              <p
                className='px-3'
                style={{ color: 'hsl(218, 81%, 85%)' }}
              >
Вартість оренди доступна для різних бюджетів, гарантуючи вам зручний та доступний відпочинок.              
</p>
<p
                className='px-3'
                style={{ color: 'hsl(218, 81%, 85%)' }}
              >
Незалежно від того, чи подорожуєте ви однією особою, чи плануєте сімейну відпустку, у нас є варіанти з різною кількістю спальних місць.</p>
<p
                className='px-3'
                style={{ color: 'hsl(218, 81%, 85%)' }}
              >
Кожен будинок обладнаний всім необхідним для комфортного проживання: повністю укомплектована кухня, сучасні санітарні вузли, а також доступ до інтернету та розважальних систем.</p>
            </MDBCol>

            <MDBCol md='6' className='position-relative'>
              <div
                id='radius-shape-1'
                className='position-absolute rounded-circle shadow-5-strong'
              ></div>
              <div
                id='radius-shape-2'
                className='position-absolute shadow-5-strong'
              ></div>

              <MDBCard className='my-5 bg-glass' style={{ width: '700px' }}>
                <MDBCardBody className='p-5'>
                  <MDBInput
                    onChange={(e) =>
                      setFormData({ ...formData, firstName: e.target.value })
                    }
                    value={formData.firstName}
                    wrapperClass='mb-4'
                    placeholder='Ваше ім`я'
                    id='form1'
                    type='text'
                  />
                  <MDBInput
                    onChange={(e) =>
                      setFormData({ ...formData, lastName: e.target.value })
                    }
                    value={formData.lastName}
                    wrapperClass='mb-4'
                    placeholder='Ваше прізвище'
                    id='form2'
                    type='text'
                  />
                  <MDBInput
                    onChange={handlePhoneNumberChange}
                    value={formData.phoneNumber}
                    wrapperClass='mb-4'
                    placeholder='Ваш номер телефону'
                    id='form3'
                  />
                  <Calendar
                    locale='uk'
                    selectRange
                    className='form-control w-100'
                    onChange={handleCalendarChange}
                    value={formData.dateRange}
                  />
                  <MDBInput
                    wrapperClass='mb-4'
                    placeholder='Выберите диапазон дат'
                    id='form4'
                    type='text'
                    value={`${formData.dateRange[0].toLocaleDateString()} - ${formData.dateRange[1].toLocaleDateString()}`}
                    readOnly
                  />
                  <button onClick={handleButtonClick} className='w-100 btn btn-primary' style={{ fontSize: '18px' }}>
                    Орендувати
                  </button>
                  <Modal show={showModal} onHide={handleCloseModal}>
                    <Modal.Header closeButton>
                      <Modal.Title>Помилка</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                      Діапазон дат зайнятий.
                    </Modal.Body>
                    <Modal.Footer>
                      <Button variant='secondary' onClick={handleCloseModal}>
                        Закрити
                      </Button>
                    </Modal.Footer>
                  </Modal>
                  <Modal show={showEmptyFieldsModal} onHide={handleCloseEmptyFieldsModal}>
        <Modal.Header closeButton>
          <Modal.Title>Помилка</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Будь ласка, заповність усі поля.
        </Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={handleCloseEmptyFieldsModal}>
            Закрити
          </Button>
        </Modal.Footer>
      </Modal>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </form>
      {/* <Footer /> */}
    </div>
  );
};

export { Room };
