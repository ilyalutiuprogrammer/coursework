import React, { useState } from 'react';
import { MyNavBar } from '../NavBar/MyNavBar';
import { Footer } from '../Footer/Footer';
import { motion } from 'framer-motion';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Background from '../../img/back4.jpg';
import Image1 from '../../img/f4.jpg';
import Modal from 'react-bootstrap/Modal';

import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput,
} from 'mdb-react-ui-kit';

const AddReviews = () => {
  const [show, setShow] = useState(false);
  const [errorModalShow, setErrorModalShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleModalClose = () => setErrorModalShow(false);
  const handleModalShow = () => setErrorModalShow(true);

  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [review, setReview] = useState('');

  const ClearInput = () => {
    setName('');
    setReview('');
  };

  const Add = (e) => {
    e.preventDefault();

    if (!name.trim() || !review.trim()) {
      handleModalShow();
      return;
    }

    axios
      .post('http://localhost:7770/api/review/add', {
        name: name,
        review: review,
      })
      .then((v) => {
        console.log(v);
        if (v.data === '') {
          navigate('/showReviews');
        } else {
          ClearInput();
        }
      });
  };

  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({ name: '', review: '' });

  return (
    <div>
      <MyNavBar />

      <div style={{ backgroundImage: `url(${Background})`, height: '100vh' }}>
        <br />
        <br />
        <br />
        <form onSubmit={(e) => Add(e)}>
          <MDBContainer fluid>
            <MDBRow>
              <MDBCol sm='6'>
                <div className='d-flex flex-row ps-5 pt-5'>
                  <span className='h1 fw-bold mb-0'>Залишіть свій відгук</span>
                </div>
                <div className='d-flex flex-column justify-content-center h-custom-2 w-75 pt-4'>
                  <MDBInput
                    onChange={(e) => setName(e.target.value)}
                    value={name}
                    wrapperClass='mb-4 mx-5 w-100'
                    placeholder='Ваше ім`я'
                    size='lg'
                  />
                  <Form.Control
                    size='lg'
                    className='mb-4 mx-5 w-100'
                    onChange={(e) => setReview(e.target.value)}
                    value={review}
                    as='textarea'
                    rows={3}
                    placeholder='Ваш відгук'
                    name='review'
                    required
                  />
                  <button
                    style={{ fontSize: '22px' }}
                    className='mb-4 px-5 mx-5 w-100 btn btn-primary'
                  >
                    Залашити відгук
                  </button>
                </div>
              </MDBCol>

              <MDBCol sm='6' className='d-none d-sm-block px-0'>
                <img
                  src={Image1}
                  className='w-100'
                  style={{
                    height: '846px',
                    objectFit: 'cover',
                    objectPosition: 'left',
                  }}
                  alt='Description of the image'
                />
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </form>
      </div>

      <Modal show={errorModalShow} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>Помилка</Modal.Title>
        </Modal.Header>
        <Modal.Body>Будь ласка, заповніть всі поля.</Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={handleModalClose}>
            Закрити
          </Button>
        </Modal.Footer>
      </Modal>

      {/* <Footer /> */}
    </div>
  );
};

export { AddReviews };
