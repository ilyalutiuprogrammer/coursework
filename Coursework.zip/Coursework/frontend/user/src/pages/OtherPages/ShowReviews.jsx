import React, { useState, useEffect } from 'react';
import { MyNavBar } from '../NavBar/MyNavBar';
import { Footer } from '../Footer/Footer';
import { motion } from 'framer-motion';
import Container from 'react-bootstrap/Container';
import Card from 'react-bootstrap/Card';
import axios from 'axios'
import  Background  from '../../img/back4.jpg';

const ShowReviews = () => {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:7770/api/showReview/show')
      .then(response => {
        setReviews(response.data);
      })
      .catch(error => {
        console.error('Ошибка при получении отзывов:', error.message);
      });
  }, []);
  

  return (
    <div style={{
      background: `url(${Background}) center center/cover no-repeat fixed`,
      minHeight: '100vh',
      overflow: 'hidden',
    }}>
      <MyNavBar />
      <br /><br /><br />
      <div>
      <Container>
        <h2 className="mt-5 mb-3">Відгуки наших клієнтів</h2>
        {reviews.map((review) => (
          <motion.div>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>{review.name}</Card.Title>
                <Card.Text>{review.review}</Card.Text>
              </Card.Body>
            </Card>
          </motion.div>
        ))}
      </Container>
      </div>
      <Footer />
    </div>
  );
};

export { ShowReviews };
