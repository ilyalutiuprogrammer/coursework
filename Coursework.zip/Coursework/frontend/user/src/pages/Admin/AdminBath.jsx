import React, { useState, useEffect } from 'react';
import { NavBarAdmin } from './NavBar/NavBarAdmin';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import { Row, Col, Image, Form } from 'react-bootstrap';
import Background from '../../img/back2.jpg';
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import Title5 from '../../img/title5.jpg';
import Modal from 'react-bootstrap/Modal';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
  MDBInput,
  MDBCard,
  MDBCardBody
} from 'mdb-react-ui-kit';
import { registerLocale, setDefaultLocale } from "react-datepicker";
import uk from "date-fns/locale/uk";
registerLocale("uk", uk);

const AdminBath = () => {
  const navigate = useNavigate();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  const [baths, setBaths] = useState([]);
  const [selectedBath, setSelectedBath] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedBathId, setSelectedBathId] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    startTime: '',
    endTime: '',
    startDate: new Date(),
  });
  const handleCloseModal = () => {
    setShowModal(false);
  };

  const fetchBath = async () => {
    try {
      const response = await axios.get('http://localhost:7770/api/admin/getBaths');
      setBaths(response.data);
    } catch (error) {
      console.error('Error fetching rooms:', error);
    }
  };

  useEffect(() => {
    fetchBath();
  }, []);

  const handleStartTimeChange = (time) => {
    setStartTime(time);
  };

  const handleEndTimeChange = (time) => {
    setEndTime({
      ...formData,
      endTime: time,
    });
  };

  const handleButtonClick = (e) => {
    e.preventDefault();

    axios.post('http://localhost:7770/api/admin/addBath', formData)
      .then(response => {
        console.log(response);
        if (response.data === '') {
          navigate('/showReviews');
        } else {
          ClearInput();
        }
      })
      .catch(error => {
        console.error('Ошибка при добавлении бани:', error);
      });
  };

  const handleUpdateBath = async () => {
    try {
      await axios.put(`http://localhost:7770/api/admin/updateBath/${selectedBathId}`, formData);
      setShowModal(false);
      fetchBath();
    } catch (error) {
      console.error('Error updating room:', error);
    }
  };
  const ClearInput = () => {
    setFormData({
      firstName: '',
      lastName: '',
      startTime: '',
      endTime: '',
      startDate: new Date(),
    });
  };
  const handleCalendarChange = (value) => {
    setFormData({
      ...formData,
      startDate: value,
    });
  };
  const handleDeleteBath = async () => {
    try{
    await axios.delete(`http://localhost:7770/api/admin/deleteBath/${selectedBathId}`)
    fetchBath();
    }catch (error) {
      console.error('Error deleting bath:', error);
    }
  };
  return (
    <div>
      <NavBarAdmin />
      <br /><br />
      <div>
        
        <form onSubmit={(e) => e.preventDefault()}>
          <MDBContainer fluid>
            <MDBRow>
              <MDBCol md='6' className='position-relative'>
              <div
                id='radius-shape-1'
                className='position-absolute rounded-circle shadow-5-strong'
              ></div>
              <div
                id='radius-shape-2'
                className='position-absolute shadow-5-strong'
              ></div>
                <MDBCard className='my-5 bg-glass' style={{ width: '700px' }}>
                <MDBCardBody className='p-5'>   
                <div className='d-flex flex-column justify-content-center h-custom-2 w-100 pt-4'>              
                 <MDBInput
                 onChange={(e) =>
                  setFormData({ ...formData, firstName: e.target.value })
                }
                    value={formData.firstName}
                    wrapperClass='mb-4'
                    placeholder='Ваше ім`я'
                    size="lg"
                  />
                  <MDBInput
                  onChange={(e) =>
                    setFormData({ ...formData, lastName: e.target.value })
                  }
                    value={formData.lastName}
                    wrapperClass='mb-4'
                    placeholder='Ваше прізвище'
                    size="lg"
                  />
                  <DatePicker
  selected={formData.startTime}
  onChange={(date) => {
    setFormData({ ...formData, startTime: date });
  }}
  placeholderText='Початок оренди'
  showTimeSelect
  showTimeSelectOnly
  timeIntervals={15}
  timeCaption="Time"
  dateFormat={"h:mm aa"}
  className='form-control mb-4 mx-auto w-100 fs-5'
/>
<DatePicker
  selected={formData.endTime}
  onChange={(date) => {
    setFormData({ ...formData, endTime: date });
  }}
  placeholderText='Кінець оренди'
  className='form-control w-100 mb-4 fs-5'
  showTimeSelect
  showTimeSelectOnly
  timeIntervals={15}
  timeCaption="Time"
  dateFormat="h:mm aa"
/>

                  <Calendar
                     onChange={handleCalendarChange}
                    value={formData.startDate}
                    locale="uk"
                    className='form-control w-100 mb-4'
                  />

                  <button
                    style={{ fontSize: '18px' }}
                    onClick={handleButtonClick}
                    className="w-100 btn btn-primary"
                  >
                    Додати
                  </button>
                  </div>
                  </MDBCardBody>
              </MDBCard>
              </MDBCol>
             {baths.map(bath => (
  <MDBCol key={bath._id} className='md-6'>
    <div
      id='radius-shape-1'
      className='position-absolute rounded-circle shadow-5-strong'
    ></div>
    <div
      id='radius-shape-2'
      className='position-absolute shadow-5-strong'
    ></div>
    <MDBCard className='my-5 bg-glass' style={{ width: '700px' }}>
      <MDBCardBody className='p-5'>
        <div>
          <p>{bath.firstName} {bath.lastName}</p>
          <p>Дата: {new Date(bath.startDate).toLocaleDateString()}</p>
          <Button variant="primary" 
          onClick={() => {
                        setSelectedBathId(bath._id);
                        setShowModal(true);
                        setFormData({
                          firstName: bath.firstName,
                          lastName: bath.lastName,
                          startTime: new Date(bath.startTime),
                          endTime: new Date(bath.endTime),
                          startDate: new Date(bath.startDate),
                        });
                      }}>
            Змінити
          </Button>
          <Button variant="danger" onClick={() => handleDeleteBath(bath._id)}>
            Видалити
          </Button>
        </div>
      </MDBCardBody>
    </MDBCard>
  </MDBCol>
))}

<Modal show={showModal} onHide={handleCloseModal}>
  <Modal.Header closeButton>
    <Modal.Title>Змінення</Modal.Title>
  </Modal.Header>
  <Modal.Body>
      <div className=' w-100 pt-4'>              
        <MDBInput
          type="text"
          className='mb-4'
          placeholder="Ваше ім'я"
          onChange={(e) =>
            setFormData({ ...formData, firstName: e.target.value })
          }
          value={formData.firstName}        
          />

        <MDBInput
          className='mb-4'
          type="text"
          placeholder="Ваше прізвище"
          onChange={(e) =>
            setFormData({ ...formData, lastName: e.target.value })
          }
          value={formData.lastName}
        />
      </div>
  </Modal.Body>
  <Modal.Footer>
    <Button variant="secondary" onClick={handleCloseModal}>
      Закрити
    </Button>
    <Button variant="primary" onClick={handleUpdateBath}>
      Змінити
    </Button>
  </Modal.Footer>
</Modal>

            </MDBRow>
          </MDBContainer>
        </form>
      </div>
    </div>
  );
};

export { AdminBath };
