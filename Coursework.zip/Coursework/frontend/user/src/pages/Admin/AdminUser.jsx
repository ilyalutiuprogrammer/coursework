import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { NavBarAdmin } from './NavBar/NavBarAdmin';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import { Row, Col, Image, Form } from 'react-bootstrap';
import Background from '../../img/blur12.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import Modal from 'react-bootstrap/Modal';
import Title4 from '../../img/title4blur.png';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
} from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom';
import 'react-datepicker/dist/react-datepicker.css';

const AdminUser = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    login: '',
    email: '',
    password:''
  });

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:7770/api/admin/getUser');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);
  return (
    <div>
      <NavBarAdmin />
      <br />
      <Container>
        <Row>
          {users.map((user, index) => (
            <Col key={user._id} md={4} className='position-relative'>
              <div
                id={`radius-shape-${index * 2 + 1}`}
                className='position-absolute rounded-circle shadow-5-strong'
              ></div>
              <div
                id={`radius-shape-${index * 2 + 2}`}
                className='position-absolute shadow-5-strong'
              ></div>
              <MDBCard className='my-5 bg-glass' style={{ width: '350px' }}>
                <MDBCardBody className='p-5'>
                  <MDBInput
                    value={user.login}
                    wrapperClass='mb-4'
                    id={`form1-${index}`}
                    type='text'
                    readOnly
                  />
                  <MDBInput
                    value={user.email}
                    wrapperClass='mb-4'
                    id={`form1-${index}`}
                    type='text'
                    readOnly
                  />  
                </MDBCardBody>
              </MDBCard>
            </Col>
          ))}
        </Row>
      </Container>
    </div>
  );
};

export { AdminUser };
