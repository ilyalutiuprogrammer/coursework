import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { NavBarAdmin } from './NavBar/NavBarAdmin';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import { Row, Col, Image, Form } from 'react-bootstrap';
import Background from '../../img/blur12.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import Modal from 'react-bootstrap/Modal';
import Title4 from '../../img/title4blur.png';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
} from 'mdb-react-ui-kit';
import { useNavigate } from 'react-router-dom';
import { registerLocale, setDefaultLocale } from 'react-datepicker';
import uk from 'date-fns/locale/uk';
import 'react-datepicker/dist/react-datepicker.css';

registerLocale('uk', uk);
setDefaultLocale('uk');

const Admin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phoneNumber: '+380',
    dateRange: [new Date(), new Date()],
  });
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const [showEmptyFieldsModal, setShowEmptyFieldsModal] = useState(false);
  const [rooms, setRooms] = useState([]);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [selectedRoomId, setSelectedRoomId] = useState(null);

  const ClearInput = () => {
    setFormData({
      firstName: '',
      lastName: '',
      phoneNumber: '+380',
      dateRange: [new Date(), new Date()],
    });
  };

  const handleButtonClick = async (e) => {
    e.preventDefault();

    if (
      formData.firstName &&
      formData.lastName &&
      formData.phoneNumber &&
      formData.dateRange[0] &&
      formData.dateRange[1]
    ) {
      try {
        const response = await axios.post(
          'http://localhost:7770/api/admin/addRoom',
          formData
        );
        console.log(response);
        if (response.data === '') {
          navigate('/showReviews');
        } else {
          ClearInput();
        }
      } catch (error) {
        console.error(error);
        if (error.response && error.response.status === 400) {
          setShowModal(true);
          setModalMessage(error.response.data.error);
        }
      }
    } else {
      setShowEmptyFieldsModal(true);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };
  const handleCloseEmptyFieldsModal = () => {
    setShowEmptyFieldsModal(false);
  };

  const handlePhoneNumberChange = (e) => {
    const value = e.target.value.replace(/\D/g, '');

    if (value.length <= 12) {
      if (!value) {
        setFormData({
          ...formData,
          phoneNumber: '+380' + value,
        });
      } else {
        setFormData({
          ...formData,
          phoneNumber: value,
        });
      }
    }
  };
  const handleDeleteRoom = async () => {
    try {
      await axios.delete(`http://localhost:7770/api/admin/deleteRoom/${selectedRoomId}`);
      setShowDeleteModal(false);
      fetchRooms();
    } catch (error) {
      console.error('Error deleting room:', error);
    }
  };

  const handleUpdateRoom = async () => {
    try {
      await axios.put(`http://localhost:7770/api/admin/updateRoom/${selectedRoomId}`, formData);
      setShowUpdateModal(false);
      fetchRooms();
    } catch (error) {
      console.error('Error updating room:', error);
    }
  };

  const handleOpenUpdateModal = (roomId) => {
    const selectedRoom = rooms.find((room) => room._id === roomId);
    setFormData({
      firstName: selectedRoom.firstName,
      lastName: selectedRoom.lastName,
      phoneNumber: selectedRoom.phoneNumber,
      dateRange: [new Date(selectedRoom.dateRange.start), new Date(selectedRoom.dateRange.end)],
    });
    setSelectedRoomId(roomId);
    setShowUpdateModal(true);
  };
  const fetchRooms = async () => {
    try {
      const response = await axios.get('http://localhost:7770/api/admin/getRooms');
      setRooms(response.data);
    } catch (error) {
      console.error('Error fetching rooms:', error);
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);


  const handleCalendarChange = (value) => {
    setFormData({
      ...formData,
      dateRange: value,
    });
  };

  return (
    <div>
      <NavBarAdmin />
      <br />
      <form onSubmit={(e) => e.preventDefault()}>
        <MDBContainer
          fluid
          className='w-100 p-3 background-radial-gradient overflow-hidden'
        >
          <MDBRow>
          <MDBCol md='6' className='position-relative'>
              <div
                id='radius-shape-1'
                className='position-absolute rounded-circle shadow-5-strong'
              ></div>
              <div
                id='radius-shape-2'
                className='position-absolute shadow-5-strong'
              ></div>

              <MDBCard className='my-5 bg-glass' style={{ width: '700px' }}>
                <MDBCardBody className='p-5'>
                  <MDBInput
                    onChange={(e) =>
                      setFormData({ ...formData, firstName: e.target.value })
                    }
                    value={formData.firstName}
                    wrapperClass='mb-4'
                    placeholder='Ваше ім`я'
                    id='form1'
                    type='text'
                  />
                  <MDBInput
                    onChange={(e) =>
                      setFormData({ ...formData, lastName: e.target.value })
                    }
                    value={formData.lastName}
                    wrapperClass='mb-4'
                    placeholder='Ваше прізвище'
                    id='form2'
                    type='text'
                  />
                  <MDBInput
                    onChange={handlePhoneNumberChange}
                    value={formData.phoneNumber}
                    wrapperClass='mb-4'
                    placeholder='Ваш номер телефону'
                    id='form3'
                  />
                  <Calendar
                    locale='uk'
                    selectRange
                    className='form-control w-100'
                    onChange={handleCalendarChange}
                    value={formData.dateRange}
                  />
                  <MDBInput
                    wrapperClass='mb-4'
                    placeholder='Выберите диапазон дат'
                    id='form4'
                    type='text'
                    value={`${formData.dateRange[0].toLocaleDateString()} - ${formData.dateRange[1].toLocaleDateString()}`}
                    readOnly
                  />
                  <button onClick={handleButtonClick} className='w-100 btn btn-primary' style={{ fontSize: '18px' }}>
                    Додати
                  </button>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
            {rooms.map((room) => (
              <MDBCol key={room._id} md='6' className='position-relative'>
                <div
                  id='radius-shape-1'
                  className='position-absolute rounded-circle shadow-5-strong'
                ></div>
                <div
                  id='radius-shape-2'
                  className='position-absolute shadow-5-strong'
                ></div>

                <MDBCard className='my-5 bg-glass' style={{ width: '700px' }}>
                  <MDBCardBody className='p-5'>
                    <MDBInput
                      value={room.firstName}
                      wrapperClass='mb-4'
                      placeholder='Ваше ім`я'
                      id='form1'
                      type='text'
                      readOnly
                    />
                    <MDBInput
                      value={room.lastName}
                      wrapperClass='mb-4'
                      placeholder='Ваше прізвище'
                      id='form2'
                      type='text'
                      readOnly
                    />
                    <MDBInput
                      value={room.phoneNumber}
                      wrapperClass='mb-4'
                      placeholder='Ваш номер телефону'
                      id='form3'
                      readOnly
                    />
                    {/* <MDBInput
                      value={`${new Date(room.dateRange.start).toLocaleDateString()} - ${new Date(room.dateRange.end).toLocaleDateString()}`}
                      wrapperClass='mb-4'
                      placeholder='Выберите диапазон дат'
                      id='form4'
                      type='text'
                      readOnly
                    /> */}
                    <Button
                      onClick={() => {
                        setSelectedRoomId(room._id);
                        setShowUpdateModal(true);
                        setFormData({
                          firstName: room.firstName,
                          lastName: room.lastName,
                          phoneNumber: room.phoneNumber,
                          dateRange: [new Date(room.dateRange.start), new Date(room.dateRange.end)],
                        });
                      }}
                      className='w-100 btn btn-primary'
                      style={{ fontSize: '18px', marginRight: '10px' }}
                    >
                      Змінити
                    </Button>
                    <Button
                         onClick={() => handleDeleteRoom(room._id)}

                      className='w-100 btn btn-danger'
                      style={{ fontSize: '18px' }}
                    >
                      Видалити
                    </Button>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            ))}
           
          </MDBRow>
        </MDBContainer>
      </form>

      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Підтвердження</Modal.Title>
        </Modal.Header>
        <Modal.Body>Ви точно хочете видалити?</Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={() => setShowDeleteModal(false)}>
            Відміна
          </Button>
          <Button variant='danger' onClick={() => handleDeleteRoom(selectedRoomId)}>
            Видалити
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showUpdateModal} onHide={() => setShowUpdateModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Змінення</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <MDBInput
            onChange={(e) =>
              setFormData({ ...formData, firstName: e.target.value })
            }
            value={formData.firstName}
            wrapperClass='mb-4'
            placeholder='Ваше ім`я'
            id='form1'
            type='text'
          />
          <MDBInput
            onChange={(e) =>
              setFormData({ ...formData, lastName: e.target.value })
            }
            value={formData.lastName}
            wrapperClass='mb-4'
            placeholder='Ваше прізвище'
            id='form2'
            type='text'
          />
          <MDBInput
            onChange={handlePhoneNumberChange}
            value={formData.phoneNumber}
            wrapperClass='mb-4'
            placeholder='Ваш номер телефону'
            id='form3'
          />
        </Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' onClick={() => setShowUpdateModal(false)}>
          Відміна
          </Button>
          <Button variant='primary' onClick={handleUpdateRoom}>
          Змінити
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export { Admin };
