import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { NavLink } from 'react-router-dom';

const NavBarAdmin = () => {
  return (
      <Navbar bg="dark" data-bs-theme="dark" className='fixed-top'>
        <Container>
          <Navbar.Brand>Admin</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link as={NavLink} to="/admin">Rooms</Nav.Link>
            <Nav.Link as={NavLink}  to="/admin_Bath">Bath</Nav.Link>
            <Nav.Link as={NavLink}  to="/admin_Fishing">Fishing</Nav.Link>
            <Nav.Link as={NavLink}  to="/admin_Reviews">Reviews</Nav.Link>
            <Nav.Link as={NavLink}  to="/admin_User">User</Nav.Link>
          </Nav>
          <Nav>
            <Nav.Link as={NavLink} to="/" eventKey={2}>
              Exit
            </Nav.Link>
          </Nav>
        </Container>
      </Navbar> 
  );
}

export { NavBarAdmin };