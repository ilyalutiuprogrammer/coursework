import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useRef, useState } from 'react';
import { MyNavBar } from '../NavBarWithoutLogin/NavBarLogin';
import { Gallery } from '../Gallery/Gallery';
import { Footer } from '../Footer/Footer';
import Background from '../../img/blur12.png';
import { motion } from 'framer-motion';
import BackSite from '../../img/back2.jpg';
import Title1 from '../../img/title1.jpg';
import Title2 from '../../img/title2.jpg';
import Title3 from '../../img/title3.jpg';
import Title4 from '../../img/title4.jpg';
import Title5 from '../../img/title5.jpg';
import Title6 from '../../img/title6.jpeg';
const MainWihthoutLogin = () => {
  const fadeInLeft = {
    hidden: { opacity: 0, x: -50 },
    visible: { opacity: 1, x: 0 },
  };

  const fadeInRight = {
    hidden: { opacity: 0, x: 50 },
    visible: { opacity: 1, x: 0 },
  };

  const [isVisibleSection1, setIsVisibleSection1] = useState(false);
  const [isVisibleSection2, setIsVisibleSection2] = useState(false);
  const [isVisibleSection3, setIsVisibleSection3] = useState(false);
  const [isVisibleSection4, setIsVisibleSection4] = useState(false);
  const [isVisibleSection5, setIsVisibleSection5] = useState(false);
  const [isVisibleSection6, setIsVisibleSection6] = useState(false);
  const [isVisibleSection7, setIsVisibleSection7] = useState(false);

  const section1Ref = useRef(null);
  const section2Ref = useRef(null);
  const section3Ref = useRef(null);
  const section4Ref = useRef(null);
  const section5Ref = useRef(null);
  const section6Ref = useRef(null);
  const section7Ref = useRef(null);

  const handleScroll = () => {
    const section1Top = section1Ref.current?.getBoundingClientRect()?.top || 0;
    const section2Top = section2Ref.current?.getBoundingClientRect()?.top || 0;
    const section3Top = section3Ref.current?.getBoundingClientRect()?.top || 0;
    const section4Top = section4Ref.current?.getBoundingClientRect()?.top || 0;
    const section5Top = section5Ref.current?.getBoundingClientRect()?.top || 0;
    const section6Top = section6Ref.current?.getBoundingClientRect()?.top || 0;
    const section7Top = section7Ref.current?.getBoundingClientRect()?.top || 0;

    setIsVisibleSection1(section1Top < window.innerHeight);
    setIsVisibleSection2(section2Top < window.innerHeight);
    setIsVisibleSection3(section3Top < window.innerHeight);
    setIsVisibleSection4(section4Top < window.innerHeight);
    setIsVisibleSection5(section5Top < window.innerHeight);
    setIsVisibleSection6(section6Top < window.innerHeight);
    setIsVisibleSection7(section7Top < window.innerHeight);

  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div>
      <MyNavBar />
      <div
        ref={section1Ref}
        style={{
          backgroundImage: `url(${Background})`,
          height: '110vh',
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <div style={{ flex: 1, padding: '50px' }}>
          <h1 style={{ fontWeight: 'bold' }}>Ласкаво просимо до нашої бази відпочинку!</h1>
          <p>
            Щоб отримати більше інформації, увійдіть до облікового запису або зареєструйте свій обліковий запис
          </p>
          <p>
            Після реєстрації можете переглянути відгуки реальних людей!          </p>
        </div>
      </div>
      <div style={{
        background: `url(${BackSite}) center center/cover no-repeat fixed`,
        minHeight: '100vh',
        overflow: 'hidden',
      }}>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <img src={Title1} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <h2>Територія</h2>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section2Ref}
              initial="hidden"
              animate={isVisibleSection2 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}
            >
                   Наша база відпочинку розташована в обрамленні живописних лісів та поруч з таємничим гірським озером. 
            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section2Ref}
              initial="hidden"
              animate={isVisibleSection2 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}

            >
              Спокійні води та зелені алеї створюють неперевершену атмосферу для відпочинку та відновлення. 
            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section2Ref}
              initial="hidden"
              animate={isVisibleSection2 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}

            >
              Ми покладаємо великий натиск на вашу безпеку та комфорт.
            </motion.p>
          </div>
        </div>
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #007BFF', width: '50%', margin: 'auto' }} />
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2>Розваги</h2>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section3Ref}
              initial="hidden"
              animate={isVisibleSection3 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
              Любителям активного відпочинку пропонуємо спортивні майданчики для волейболу, баскетболу та футболу.
            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section3Ref}
              initial="hidden"
              animate={isVisibleSection3 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
              Наш вечірній розваговий розклад наповнений захоплюючими виступами, тематичними вечорами та музичними фестивалями. 
            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section3Ref}
              initial="hidden"
              animate={isVisibleSection3 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
              Ми покладаємо великий акцент на веселощі для дітей. 
            </motion.p>
          </div>
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Title2} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #FF6347', width: '50%', margin: 'auto' }} />
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <img src={Title3} alt="Additional Image 1" style={{  width: '100%', borderRadius: '8px' }} />
            <h2>Вид зверху</h2>
            <motion.p
            ref={section5Ref}
            initial="hidden"
            animate={isVisibleSection5 ? 'visible' : 'hidden'}
            variants={fadeInLeft}
            transition={{ duration: 1.5 }}
            style={{ fontSize:'20px' }}>
              
              Яка наймовірна краса!
            </motion.p>
          </div>
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <img src={Title4} alt="Additional Image 2" style={{ height: '592px', width: '100%', borderRadius: '8px' }} />
            <h2>Альтанки</h2>
            <motion.p
             ref={section5Ref}
             initial="hidden"
             animate={isVisibleSection5 ? 'visible' : 'hidden'}
             variants={fadeInLeft}
             transition={{ duration: 1.5 }}
             style={{ fontSize:'20px' }}>
              Дуже красиво сидіти ввечері!
            </motion.p>
          </div>
        </div>
      </div>
      <hr className="my-4" style={{ borderTop: '2px solid #FF6347', width: '50%', margin: 'auto' }} />

      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <img src={Title5} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <div>
            <h2>Лазня</h2>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section6Ref}
              initial="hidden"
              animate={isVisibleSection6 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}
            >
            Ми пропонуємо різноманітні пакети послуг та тривалості сеансів, щоб кожен гість міг знайти оптимальний варіант для себе.            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section6Ref}
              initial="hidden"
              animate={isVisibleSection6 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}
            >
            Після процедур відпочиньте у нашій затишній релаксаційній зоні або вируште на терасу з чудовим видом на природу.            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section6Ref}
              initial="hidden"
              animate={isVisibleSection6 ? 'visible' : 'hidden'}
              variants={fadeInLeft}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginLeft:'30px' }}
            >
            Отримайте задоволення від гідромасажу в наших спеціально обладнаних ваннах.            </motion.p>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', padding: '50px' }}>
        <div style={{ flex: 1 }}>
          <div>
            <h2>Риболовля</h2>
            <br/>
            <br/>
            <br/>
            <motion.p
              ref={section7Ref}
              initial="hidden"
              animate={isVisibleSection7 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
            Після активного дня риболовлі ви можете відпочити у затишному місці біля води, де готується свіже барбекю.             
            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section7Ref}
              initial="hidden"
              animate={isVisibleSection7 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
            Для тих, хто любить конкуренцію, ми регулярно проводимо риболовні турніри та змагання.            </motion.p>
            <br/>
            <br/>
            <motion.p
              ref={section7Ref}
              initial="hidden"
              animate={isVisibleSection7 ? 'visible' : 'hidden'}
              variants={fadeInRight}
              transition={{ duration: 1.5 }}
              style={{ fontSize:'25px', marginRight:'30px' }}
            >
            Приєднуйтесь до нас і дозвольте собі пірнути в світ неймовірних рибальських емоцій!            </motion.p>
          </div>
        </div>
        <div style={{ flex: 1, paddingLeft: '20px' }}>
          <img src={Title6} alt="Background" style={{ width: '100%', borderRadius: '8px' }} />
        </div>
      </div>
      </div>
      <Footer />
    </div>
  );
};

export { MainWihthoutLogin };
